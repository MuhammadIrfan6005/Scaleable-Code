﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System.Runtime.Serialization;

namespace Scaleable.Xrm.Plugins.OppWin.UpdProbib
{
    public class UpdateProbibility : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            #region Standard Initializations

            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService =
                (ITracingService)serviceProvider.GetService(typeof(ITracingService));


            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Get a reference to the Organization service.
            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            #endregion

            tracingService.Trace("Probability Updation Fired");
            try
            {
                if ((context.InputParameters.Contains("OpportunityClose") && context.InputParameters["OpportunityClose"] is Entity))
                {
                    Entity opptyClose = (Entity)context.InputParameters["OpportunityClose"];
                    EntityReference opptyRef = opptyClose["opportunityid"] as EntityReference;

                    Entity opportunity = new Entity("opportunity", opptyRef.Id);    //opptyRef.Id contains our required id
                    opportunity["closeprobability"] = 100;
                    service.Update(opportunity);
                    tracingService.Trace("Probability Updated");
                }
                else
                    tracingService.Trace("Probability Updated Doesn't Contain OpportunityClose entity");
            }
            catch (Exception e)
            {
                tracingService.Trace("Probability Error: "+e+"");
            }
            
        }
    }
}
