﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scaleable.Xrm.Plugins.PC.UpdateRgACC
{
   public  class activityData
    {
        public DateTime? latestClosestDate { get; set; }
        public OptionSetValue latestStatus { get; set; }
        public EntityReference owner { get; set; }
        public bool isNoActivity { get; set; }

    }
}
