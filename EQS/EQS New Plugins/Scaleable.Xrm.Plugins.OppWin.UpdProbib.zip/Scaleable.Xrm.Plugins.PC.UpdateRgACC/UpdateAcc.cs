﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;

namespace Scaleable.Xrm.Plugins.PC.UpdateRgACC
{
    public class UpdateAcc : IPlugin
    {
        public string followUpStatus;
        public string followUpType;
        private string formTypeFollowup;
        activityData result;
   

        public static activityData SetFollowup(IServiceProvider serviceProvider, DateTime currentFollowUp, OptionSetValue currentStatus, EntityReference regarding, string followupType, string followupStatus, int formType, string formTypeFollowup)
        {
            
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);


                //Initializing Varaiables
                OptionSetValue pcCloserStatus = null, tcCloserStatus = null, latestCloserStatus = null;
                DateTime? pcCloserDateTime = null, tcCloserDateTim = null, latestClosestDate = null;
                EntityReference pcCloserOwner = null, tcCloserOwner = null, latestClosestOwner=null;
                bool isNoActivity = false;

                //Retreiving Account - Follow up Regarding to account record selected
                Entity accEntity = new Entity("account");
                tracingService.Trace("Inside the funtion");
                tracingService.Trace("Followup" + followupType);
                tracingService.Trace("form type Followup " + formTypeFollowup);
                DateTime todayDateTime = new DateTime(1755, 01, 01);


              



            
                tracingService.Trace("Current Date"+currentFollowUp);

                //Query Expressions for Retreiving Data from Task and Phone Call Entity
                var QEphonecall = new QueryExpression("phonecall");
                var QEtask = new QueryExpression("task");
                //Define Filtered Columns
                QEphonecall.ColumnSet.AddColumn(followupType);
                QEphonecall.ColumnSet.AddColumn(followupStatus);
                QEtask.ColumnSet.AddColumn(followupType);
                QEtask.ColumnSet.AddColumn(followupStatus);
                QEphonecall.ColumnSet.AddColumn("ownerid");
                QEtask.ColumnSet.AddColumn("ownerid");

                // Define filter QEphonecall.Criteria
                QEphonecall.Criteria.AddCondition(followupType, ConditionOperator.NotNull);
                QEtask.Criteria.AddCondition(followupType, ConditionOperator.NotNull);

                
                QEphonecall.Criteria.AddCondition("ss_formtype", ConditionOperator.Equal, formType);
                QEtask.Criteria.AddCondition("ss_formtype", ConditionOperator.Equal, formType);
                QEphonecall.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                QEtask.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

              
                ConditionExpression regardingCondition = new ConditionExpression();
                regardingCondition.AttributeName = "regardingobjectid";
                regardingCondition.Operator = ConditionOperator.In;
                regardingCondition.Values.Add(regarding.Id);

                if (regarding.LogicalName != "opportunity")
                {
                    var QEcontact = new QueryExpression("contact");
                    QEcontact.ColumnSet.AddColumns("contactid");

                    QEcontact.Criteria.AddCondition("parentcustomerid", ConditionOperator.Equal, regarding.Id);
                    EntityCollection contactCollection = service.RetrieveMultiple(QEcontact);
                    if (contactCollection.Entities.Count > 0)
                    {
                        foreach (Entity contact in contactCollection.Entities)
                        {
                            regardingCondition.Values.Add(contact.Id);
                            tracingService.Trace("Contacts count " + contactCollection.Entities.Count);
                        }
                    }
                }

                QEphonecall.Criteria.AddCondition(regardingCondition);
                QEtask.Criteria.AddCondition(regardingCondition);

                //Retreiving Data
                EntityCollection pcCollection = service.RetrieveMultiple(QEphonecall);
                EntityCollection tcCollection = service.RetrieveMultiple(QEtask);

                //Closest Followup and Status Algo
                if (pcCollection.Entities.Count > 0)
                {
                    foreach (Entity val in pcCollection.Entities)
                    {

                     
                            if (pcCloserDateTime == null)
                            {
                                pcCloserDateTime = (DateTime)val[followupType];
                                pcCloserOwner=(EntityReference)val["ownerid"];
                                if (val.Attributes.Contains(followupStatus))
                                {
                                    pcCloserStatus = (OptionSetValue)val[followupStatus];
                                }
                                else
                                {
                                    pcCloserStatus = new OptionSetValue();
                                }
                                

                            }
                            else
                            {
                                if (pcCloserDateTime > (DateTime)val[followupType])
                                {
                                    pcCloserDateTime = (DateTime)val[followupType];
                                     pcCloserOwner=(EntityReference)val["ownerid"];
                                    if (val.Attributes.Contains(followupStatus))
                                    {
                                        pcCloserStatus = (OptionSetValue)val[followupStatus];
                                    }
                                    else
                                    {
                                        pcCloserStatus = new OptionSetValue();
                                    }
                                
                                }
                            }
                        


                    }
                }

                if (tcCollection.Entities.Count > 0)
                {


                    foreach (Entity val in tcCollection.Entities)
                    {

                       if (tcCloserDateTim == null)
                            {

                                tcCloserDateTim = (DateTime)val[followupType];
                                tcCloserOwner = (EntityReference)val["ownerid"];
                                if (val.Attributes.Contains(followupStatus))
                                {
                                    tcCloserStatus = (OptionSetValue)val[followupStatus];
                                }
                                else
                                    tcCloserStatus = new OptionSetValue();

                            }
                            else
                            {


                                if (tcCloserDateTim > (DateTime)val[followupType])
                                {
                                    tcCloserDateTim = (DateTime)val[followupType];
                                    tcCloserOwner = (EntityReference)val["ownerid"];
                                    if (val.Attributes.Contains(followupStatus))
                                    {
                                        tcCloserStatus = (OptionSetValue)val[followupStatus];
                                    }
                                    else
                                        tcCloserStatus = new OptionSetValue();

                                }
                            }
                        

                    }
                }

                if (pcCloserDateTime != null && tcCloserDateTim != null)
                {
                    tracingService.Trace("Both PC and Task are not null");
                    if (pcCloserDateTime <= tcCloserDateTim)
                    {
                        latestClosestDate = pcCloserDateTime;
                        latestCloserStatus = pcCloserStatus;
                        latestClosestOwner = pcCloserOwner;
                    }
                    else
                    {
                        latestClosestDate = tcCloserDateTim;
                        latestCloserStatus = tcCloserStatus;
                        latestClosestOwner = tcCloserOwner;
                    }



                }



                else
                {
                    if (pcCloserDateTime == null && tcCloserDateTim == null)
                    {
                        tracingService.Trace("Both Task and Phone call are null");
                        
                           
                            latestClosestDate = new DateTime();
                            latestCloserStatus = new OptionSetValue();
                            tracingService.Trace("Date and Status has been set default");
                            latestClosestOwner = null;
                            isNoActivity = true;
                            tracingService.Trace("Owner is set null");

                    }
                    else if (pcCloserDateTime == null)
                    {
                        tracingService.Trace("PC is null");
                        latestClosestDate = tcCloserDateTim;
                        latestCloserStatus = tcCloserStatus;
                        latestClosestOwner = tcCloserOwner;
                    }
                    else if (tcCloserDateTim == null)
                    {
                        tracingService.Trace("task is null");
                        latestClosestDate = pcCloserDateTime;
                        latestCloserStatus = pcCloserStatus;
                        latestClosestOwner = pcCloserOwner;
                    }



                }
                if (latestClosestDate == null)
                {
                    tracingService.Trace("latest Closest date is null");
                    latestCloserStatus = new OptionSetValue();
                    latestClosestDate = new DateTime();
                    latestClosestOwner = null;
                    isNoActivity = true;
                }

                activityData obj = new activityData();
                obj.latestClosestDate = latestClosestDate;
                obj.latestStatus = latestCloserStatus;
                obj.owner = latestClosestOwner;
                obj.isNoActivity = isNoActivity;
                tracingService.Trace("Before returning and checking Systemuser check");

                if (latestClosestOwner == null)
                {
                    obj.owner = null;
                }

                else if (latestClosestOwner.LogicalName == "systemuser")
                {
                    tracingService.Trace("logical Name is not User" + latestClosestOwner.LogicalName);
                    obj.owner = latestClosestOwner;
                    tracingService.Trace("Owner is set");

                }
                else
                {
                    obj.owner = null;
                    tracingService.Trace("owner is set null");
                }

                return obj;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in the Scalable.Xrm.Plugins.PC.UpdateRgACC plug-in.", ex);

            }

        }
        public void Execute(IServiceProvider serviceProvider)
        {
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
           /// Plugin Name= Scalable.Xrm.Plugins.PC.UpdateRgACC                                                                  ///
          /// Target Entity= PhoneCall and Task                                                                                 ///
         /// Message= Post Create/Update                                                                                       ///
        /// Description: It sets the next Open Activity on Account                                                            ///
       /// Image Name: PrePC ( Status field, statecode, due date, regarding, owner                                           ///
      /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            // Obtain the execution context from the service provider.
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService =
                  (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the organization service reference.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);



            
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                //checking whether plugin is fired from Phone Call
                if ((entity.LogicalName != "phonecall") && (entity.LogicalName != "task"))
                {
                    return;
                }
                if (context.Depth > 1)
                {
                    return;
                }

                Entity preEntityImage = new Entity();
                if (context.MessageName.ToUpper() == "UPDATE")
                {
                    //getting preImage of Entity
                    preEntityImage = (Entity)context.PreEntityImages["PrePC"];

                }
                try
                {

                    if ((entity.Attributes.Contains("regardingobjectid")) || (entity.Attributes.Contains("ownerid")) || (entity.Attributes.Contains("scheduledend")) || (entity.Attributes.Contains("ss_xmlstatus")) || (entity.Attributes.Contains("ss_irstatus")) || (entity.Attributes.Contains("ss_prstatus")) || (entity.Attributes.Contains("ss_ccstatus")) || (entity.Attributes.Contains("ss_costatus")) || (entity.Attributes.Contains("statecode")) || (entity.Attributes.Contains("ss_formtype")))
                    {

                        OptionSetValue xmlstatus = new OptionSetValue();
                        OptionSetValue irStatus = new OptionSetValue();
                        OptionSetValue prStatus = new OptionSetValue();
                        OptionSetValue ccStatus = new OptionSetValue();
                        OptionSetValue coStatus = new OptionSetValue();

                        OptionSetValue formType = new OptionSetValue();
                        DateTime dueDate = new DateTime();
                        Entity accnt = new Entity();
                        Entity opp = new Entity();

                        Guid initiatingUserId = context.InitiatingUserId;
                        EntityReference followupUser = new EntityReference("systemuser", initiatingUserId);

                        EntityReference regarding = new EntityReference();
                        EntityReference owner = new EntityReference();
                        EntityReference regardingAccount = new EntityReference();
                        if (entity.Attributes.Contains("regardingobjectid"))
                        {
                            if (entity["regardingobjectid"] != null)
                            {
                                regarding = entity.GetAttributeValue<EntityReference>("regardingobjectid");
                            }

                        }
                        else
                        {
                            if (context.MessageName.ToUpper() == "UPDATE")
                            {

                                if (preEntityImage.Attributes.Contains("regardingobjectid"))
                                {
                                    regarding = preEntityImage.GetAttributeValue<EntityReference>("regardingobjectid");
                                }
                            }
                        }

                        if (!(regarding.LogicalName == "account") && !(regarding.LogicalName == "opportunity") && !(regarding.LogicalName == "contact"))
                        {
                            return;
                        }
                        if ((regarding == null))
                        {
                            tracingService.Trace("regarding is null");
                            return;
                        }
                        else
                        {


                            if (context.MessageName.ToUpper() == "CREATE")
                            {
                                if (entity.Attributes.Contains("ownerid"))
                                {
                                    owner = entity.GetAttributeValue<EntityReference>("ownerid");
                                }

                                if (entity.Attributes.Contains("scheduledend"))
                                {
                                    if (entity["scheduledend"] != null)
                                    {
                                        dueDate = (DateTime)entity["scheduledend"];
                                    }
                                }

                                if (entity.Attributes.Contains("ss_formtype"))
                                {
                                    if (entity["ss_formtype"] != null)
                                    {
                                        formType = (OptionSetValue)entity["ss_formtype"];
                                    }
                                }


                                if (entity.Attributes.Contains("ss_xmlstatus"))
                                {
                                    if (entity["ss_xmlstatus"] != null)
                                    {
                                        xmlstatus = (OptionSetValue)entity["ss_xmlstatus"];
                                    }

                                }
                                else if (entity.Attributes.Contains("ss_irstatus"))
                                {
                                    if (entity["ss_irstatus"] != null)
                                    {
                                        irStatus = (OptionSetValue)entity["ss_irstatus"];
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_prstatus"))
                                {
                                    if (entity["ss_prstatus"] != null)
                                    {
                                        prStatus = (OptionSetValue)entity["ss_prstatus"];
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_ccstatus"))
                                {
                                    if (entity["ss_ccstatus"] != null)
                                    {
                                        ccStatus = (OptionSetValue)entity["ss_ccstatus"];
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_costatus"))
                                {
                                    if (entity["ss_costatus"] != null)
                                    {
                                        coStatus = (OptionSetValue)entity["ss_costatus"];
                                    }
                                }

                            }

                            else if (context.MessageName.ToUpper() == "UPDATE")
                            {

                                if (entity.Attributes.Contains("ownerid"))
                                {

                                    owner = entity.GetAttributeValue<EntityReference>("ownerid");
                                }
                                else if (preEntityImage.Attributes.Contains("ownerid"))
                                {

                                    owner = preEntityImage.GetAttributeValue<EntityReference>("ownerid");
                                }

                                if (entity.Attributes.Contains("scheduledend"))
                                {
                                    if (entity["scheduledend"] != null)
                                    {
                                        dueDate = (DateTime)entity["scheduledend"];
                                    }
                                }
                                else if (preEntityImage.Attributes.Contains("scheduledend"))
                                {
                                    dueDate = (DateTime)preEntityImage["scheduledend"];
                                }

                                if (entity.Attributes.Contains("ss_formtype"))
                                {
                                    if (entity["ss_formtype"] != null)
                                    {
                                        formType = (OptionSetValue)entity["ss_formtype"];
                                    }
                                }
                                else if (preEntityImage.Attributes.Contains("ss_formtype"))
                                {
                                    formType = (OptionSetValue)preEntityImage["ss_formtype"];
                                }

                                if (entity.Attributes.Contains("ss_xmlstatus"))
                                {
                                    if (entity["ss_xmlstatus"] != null)
                                    {
                                        xmlstatus = (OptionSetValue)entity["ss_xmlstatus"];
                                    }
                                    else
                                    {
                                        accnt["ss_xmlstatus"] = null;
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_irstatus"))
                                {
                                    if (entity["ss_irstatus"] != null)
                                    {
                                        irStatus = (OptionSetValue)entity["ss_irstatus"];
                                    }
                                    else
                                    {
                                        accnt["ss_irstatus"] = null;
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_prstatus"))
                                {
                                    if (entity["ss_prstatus"] != null)
                                    {
                                        prStatus = (OptionSetValue)entity["ss_prstatus"];
                                    }
                                    else
                                    {
                                        accnt["ss_prstatus"] = null;
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_ccstatus"))
                                {
                                    if (entity["ss_ccstatus"] != null)
                                    {
                                        ccStatus = (OptionSetValue)entity["ss_ccstatus"];
                                    }
                                    else
                                    {
                                        accnt["ss_ccstatus"] = null;
                                    }
                                }
                                else if (entity.Attributes.Contains("ss_costatus"))
                                {
                                    if (entity["ss_costatus"] != null)
                                    {
                                        coStatus = (OptionSetValue)entity["ss_costatus"];
                                    }
                                    else
                                    {
                                        accnt["ss_costatus"] = null;
                                    }
                                }
                                else
                                {
                                    if (preEntityImage.Attributes.Contains("ss_xmlstatus"))
                                    {
                                        xmlstatus = (OptionSetValue)preEntityImage["ss_xmlstatus"];
                                    }
                                    else if (preEntityImage.Attributes.Contains("ss_irstatus"))
                                    {
                                        irStatus = (OptionSetValue)preEntityImage["ss_irstatus"];
                                    }
                                    else if (preEntityImage.Attributes.Contains("ss_prstatus"))
                                    {
                                        prStatus = (OptionSetValue)preEntityImage["ss_prstatus"];
                                    }
                                    else if (preEntityImage.Attributes.Contains("ss_ccstatus"))
                                    {
                                        ccStatus = (OptionSetValue)preEntityImage["ss_ccstatus"];
                                    }
                                    else if (preEntityImage.Attributes.Contains("ss_costatus"))
                                    {
                                        coStatus = (OptionSetValue)preEntityImage["ss_costatus"];
                                    }
                                }
                            }


                        }

                        // Entity accnt = new Entity("account");
                        if (regarding.LogicalName == "account")
                        {
                            regardingAccount = regarding;
                            accnt.LogicalName = regarding.LogicalName;
                            accnt.Id = regarding.Id;
                          
                        }
                        else if (regarding.LogicalName == "opportunity")
                        {
                            regardingAccount = regarding;
                            opp.LogicalName = regarding.LogicalName;
                            opp.Id = regarding.Id;
                            accnt.LogicalName = "account";
                            ColumnSet cols = new ColumnSet(new String[] { "parentaccountid" });
                            Entity regardingaccount = service.Retrieve(regarding.LogicalName, regarding.Id, cols);
                            if (regardingaccount.Attributes.Contains("parentaccountid"))
                            {
                                accnt.Id = ((EntityReference)regardingaccount["parentaccountid"]).Id;
                                
                            }
                        }
                        else if (regarding.LogicalName == "contact")
                        {
                            tracingService.Trace("Regarding is contact");
                
                         
                           
                            accnt.LogicalName = "account";
                            ColumnSet cols = new ColumnSet(new String[] { "parentcustomerid" });
                            Entity regardingaccount = service.Retrieve(regarding.LogicalName, regarding.Id, cols);
                            if (regardingaccount.Attributes.Contains("parentcustomerid"))
                            {
                                accnt.Id = ((EntityReference)regardingaccount["parentcustomerid"]).Id;
                                regardingAccount = new EntityReference("account", accnt.Id);
                               
                            }
                            else
                            {
                                return;
                            }

                        }
                        DateTime def = new DateTime();
                        switch (formType.Value)
                        {
                            case 1:
                                
                                formTypeFollowup = "ss_xmlfollowup";
                                followUpType = "scheduledend";
                                followUpStatus = "ss_xmlstatus";

                                if ((regarding.LogicalName == "account") || (regarding.LogicalName == "contact"))
                                {
                              
                                    accnt["ss_ownernextxmlactivity"] = null;
                                    result = SetFollowup(serviceProvider, dueDate, xmlstatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                   
                                   tracingService.Trace("function returned");
                                   if (result.isNoActivity == true)
                                   {
                                       tracingService.Trace("Plugin is returning as there is no Open activity");
                                       return;
                                   }
                                   tracingService.Trace("There are some open activities");
                                    dueDate = (DateTime)result.latestClosestDate;
                                    xmlstatus = result.latestStatus;
                                    owner = result.owner;
                                    accnt["ss_ownernextxmlactivity"] = owner;
                                }

                                else if ((regarding.LogicalName == "opportunity"))
                                {

                                    result = SetFollowup(serviceProvider, dueDate, xmlstatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    tracingService.Trace("function returned");
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    dueDate = (DateTime)result.latestClosestDate;
      
                                }

                           
                                accnt["ss_xmlfollowupuser"] = followupUser;
                                accnt["ss_xmlstatus"] = null;
                                


                                if (dueDate == def)
                                {
                                    accnt["ss_xmlfollowup"] = null;
                                }
                                else
                                {
                                    accnt["ss_xmlfollowup"] = dueDate;
                                }

                                if (opp.LogicalName == "opportunity")
                                {
                                    if (dueDate == def)
                                    {
                                        opp["new_followup"] = null;
                                    }
                                    else
                                    {
                                        opp["new_followup"] = dueDate;
                                    }
                                }

                                if (xmlstatus.Value != 0)
                                {
                                    accnt["ss_xmlstatus"] = xmlstatus;
                                }



                                if (regarding.LogicalName != "opportunity")
                                {
                                    service.Update(accnt);
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    service.Update(opp);
                                }
                                //}
                                break;
                            case 2:

                                tracingService.Trace("Inside IR");
                                formTypeFollowup = "ss_irfollowup";
                                followUpType = "scheduledend";
                                followUpStatus = "ss_irstatus";

                                if ((regarding.LogicalName == "account") || (regarding.LogicalName == "contact"))
                                {
                                    accnt["ss_ownernextiractivity"] = null;
                                    result = SetFollowup(serviceProvider, dueDate, irStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    tracingService.Trace("There are some open activities");
                                    dueDate = (DateTime)result.latestClosestDate;
                                    irStatus = result.latestStatus;
                                    owner = result.owner;
                                    accnt["ss_ownernextiractivity"] = owner;
                                }
                                else if ((regarding.LogicalName == "opportunity"))
                                {

                                    result = SetFollowup(serviceProvider, dueDate, irStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    tracingService.Trace("function returned");
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    dueDate = (DateTime)result.latestClosestDate;

                                }
                        
                              accnt["ss_irfollowupuser"] = followupUser;
                                accnt["ss_irstatus"] = null;


                                if (dueDate == def)
                                {
                                    accnt["ss_irfollowup"] = null;

                                }
                                else
                                {

                                    accnt["ss_irfollowup"] = dueDate;

                                }

                                if (opp.LogicalName == "opportunity")
                                {
                                    if (dueDate == def)
                                    {
                                        opp["new_followup"] = null;
                                    }
                                    else
                                    {
                                        opp["new_followup"] = dueDate;
                                    }
                                }
                                if (irStatus.Value != 0)
                                {
                                    accnt["ss_irstatus"] = irStatus;
                                }


                                if (regarding.LogicalName != "opportunity")
                                {
                                    service.Update(accnt);
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    service.Update(opp);
                                }
                                //}
                                break;
                            case 3:

                              
                                formTypeFollowup = "ss_prfollowup";
                                followUpType = "scheduledend";
                                followUpStatus = "ss_prstatus";
                                if ((regarding.LogicalName == "account") || (regarding.LogicalName == "contact"))
                                {
                                    accnt["ss_ownernextpractivity"] = null;
                                    result = SetFollowup(serviceProvider, dueDate, prStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    tracingService.Trace("There are some open activities");
                                    
                                    dueDate = (DateTime)result.latestClosestDate;
                                    prStatus = result.latestStatus;
                                    owner = result.owner;
                                    accnt["ss_ownernextpractivity"] = owner;
                                }
                                else if ((regarding.LogicalName == "opportunity"))
                                {

                                    result = SetFollowup(serviceProvider, dueDate, prStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    tracingService.Trace("function returned");
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    dueDate = (DateTime)result.latestClosestDate;

                                }
                                
                             accnt["ss_prfollowupuser"] = followupUser;
                                accnt["ss_prstatus"] = null;
                                if (dueDate == def)
                                {
                                    accnt["ss_prfollowup"] = null;
                                }
                                else
                                {

                                    accnt["ss_prfollowup"] = dueDate;

                                }

                                if (opp.LogicalName == "opportunity")
                                {
                                    if (dueDate == def)
                                    {
                                        opp["new_followup"] = null;
                                    }
                                    else
                                    {
                                        opp["new_followup"] = dueDate;
                                    }
                                }

                                if (prStatus.Value != 0)
                                {
                                    accnt["ss_prstatus"] = prStatus;
                                }

                                if (regarding.LogicalName != "opportunity")
                                {
                                    service.Update(accnt);
                                }

                                if (opp.LogicalName == "opportunity")
                                {
                                    service.Update(opp);
                                }

                                break;
                            case 4:
                                formTypeFollowup = "ss_ccfollowup"; 
                                 followUpType = "scheduledend";
                                followUpStatus = "ss_ccstatus";
                                if ((regarding.LogicalName == "account") || (regarding.LogicalName == "contact"))
                                {
                                    accnt["ss_ownernextccactivity"] = null;
                                    result = SetFollowup(serviceProvider, dueDate, ccStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    tracingService.Trace("There are some open activities");
                                    
                                    dueDate = (DateTime)result.latestClosestDate;
                                    ccStatus = result.latestStatus;
                                    owner = result.owner;
                                    accnt["ss_ownernextccactivity"] = owner;
                                }
                                else if ((regarding.LogicalName == "opportunity"))
                                {

                                    result = SetFollowup(serviceProvider, dueDate, ccStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    tracingService.Trace("function returned");
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    dueDate = (DateTime)result.latestClosestDate;

                                }
                                
                              accnt["ss_ccfollowupuser"] = followupUser;
                                accnt["ss_ccstatus"] = null;
                                if (dueDate == def)
                                {
                                    accnt["ss_ccfollowup"] = null;
                                }
                                else
                                {
                                    accnt["ss_ccfollowup"] = dueDate;
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    if (dueDate == def)
                                    {
                                        opp["new_followup"] = null;
                                    }
                                    else
                                    {
                                        opp["new_followup"] = dueDate;
                                    }
                                }
                                if (ccStatus.Value != 0)
                                {
                                    accnt["ss_ccstatus"] = ccStatus;
                                }

                                if (regarding.LogicalName != "opportunity")
                                {
                                    service.Update(accnt);
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    service.Update(opp);
                                }
                                break;
                            case 5:
                                formTypeFollowup = "ss_cofollowup";
                                followUpType = "scheduledend";
                                followUpStatus = "ss_costatus";
                                if ((regarding.LogicalName == "account") || (regarding.LogicalName == "contact"))
                                {
                                    accnt["ss_ownernextcoactivity"] = null;
                                    result = SetFollowup(serviceProvider, dueDate, coStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    tracingService.Trace("There are some open activities");

                                    dueDate = (DateTime)result.latestClosestDate;
                                    coStatus = result.latestStatus;
                                    owner = result.owner;
                                    accnt["ss_ownernextcoactivity"] = owner;
                                }
                                else if ((regarding.LogicalName == "opportunity"))
                                {

                                    result = SetFollowup(serviceProvider, dueDate, coStatus, regardingAccount, followUpType, followUpStatus, formType.Value, formTypeFollowup);
                                    tracingService.Trace("function returned");
                                    if (result.isNoActivity == true)
                                    {
                                        tracingService.Trace("Plugin is returning as there is no Open activity");
                                        return;
                                    }
                                    dueDate = (DateTime)result.latestClosestDate;

                                }

                                accnt["ss_cofollowupuser"] = followupUser;
                                accnt["ss_costatus"] = null;
                                if (dueDate == def)
                                {
                                    accnt["ss_cofollowup"] = null;
                                }
                                else
                                {
                                    tracingService.Trace("Setting Co Follow-Up" + dueDate.ToString());
                                    accnt["ss_cofollowup"] = dueDate;
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    if (dueDate == def)
                                    {
                                        opp["new_followup"] = null;
                                    }
                                    else
                                    {
                                        opp["new_followup"] = dueDate;
                                    }
                                }
                                if (coStatus.Value != 0)
                                {
                                    tracingService.Trace("Setting Co Status" + coStatus.Value.ToString());

                                    accnt["ss_costatus"] = coStatus;
                                }

                                if (regarding.LogicalName != "opportunity")
                                {
                                    service.Update(accnt);
                                }
                                if (opp.LogicalName == "opportunity")
                                {
                                    service.Update(opp);
                                }
                                break;
                            default:
                                return;
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in the Scalable.Xrm.Plugins.PC.UpdateRgACC plug-in.", ex);
                }

            }

        }


    }
}
