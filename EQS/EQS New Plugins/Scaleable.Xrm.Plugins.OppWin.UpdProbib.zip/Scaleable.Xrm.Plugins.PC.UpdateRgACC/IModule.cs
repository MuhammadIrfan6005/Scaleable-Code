﻿using System;

#region Assembly Microsoft.Xrm.Sdk, Version=7.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// C:\Visual Studio\Plugin\Scaleable.Xrm.Plugins.PC.UpdateRgACC\Scaleable.Xrm.Plugins.PC.UpdateRgACC\bin\Debug\Microsoft.Xrm.Sdk.dll
#endregion


namespace Microsoft.Xrm.Sdk
{
    interface IModule
    {
        void Execute(IServiceProvider serviceProvider);
    }
}
