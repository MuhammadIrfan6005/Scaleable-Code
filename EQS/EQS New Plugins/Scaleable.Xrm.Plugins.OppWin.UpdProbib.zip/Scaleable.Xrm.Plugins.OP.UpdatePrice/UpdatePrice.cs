﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;

namespace Scalable.Xrm.Plugins.OP.UpdatePrice
{
    public class UpdatePrice : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            /// Plugin Name= Scalable.Xrm.Plugins.UpdateDiscount                                                                  ///
            /// Target Entity= oppurtinity                                                                                        ///
            /// Message= Pre Update                                                                                               ///
            /// Description: It will recalculate the Individual Discount(manualdiscountamount) of opportunityproducts when        /// 
            /// we Update the overall discount on Opportunity.                                                                    ///
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



            // Obtain the execution context from the service provider.
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            ITracingService tracingService =
                  (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Obtain the organization service reference.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);



            if (context.InputParameters.Contains("Target") &&
                  context.InputParameters["Target"] is Entity)
            {

                Entity entity = (Entity)context.InputParameters["Target"];
                //checking whether plugin is fired from Opportunity Entity
                if (entity.LogicalName != "opportunity")
                {
                    return;
                }
                if (context.Depth > 1)
                {
                    return;
                }

                //getting preImage of Entity
                Entity preEntityImage = (Entity)context.PreEntityImages["PreOpp"];


                //Getting Id of current Opportunity Record
                Guid Opportunityid = entity.Id;



                try
                {

                    // Check if ss_discountinamount has changed then execute this code
                    if ((entity.Attributes.Contains("ss_discountinamount")) || (entity.Attributes.Contains("ss_discountinpercentage")) || (entity.Attributes.Contains("totalamount")))
                    {



                        //totalDiscount is sum of calculations of discountinamount and discountinpercentage
                        Money totalDiscount = new Money(0);
                        decimal percentage = 0;
                        Money discountInAmount = new Money(0);
                        //Checking different possibilities of change in discount Values
                        if (entity.Attributes.Contains("ss_discountinamount"))
                        {
                            if (entity["ss_discountinamount"] == null)
                            {
                                discountInAmount.Value = 0;
                            }
                            else
                            {
                                discountInAmount = (Money)entity["ss_discountinamount"];
                            }
                        }
                        else
                        {
                            if (preEntityImage.Attributes.Contains("ss_discountinamount"))
                            {
                                discountInAmount = (Money)preEntityImage["ss_discountinamount"];
                            }
                        }

                        if (entity.Attributes.Contains("ss_discountinpercentage"))
                        {
                            if (entity["ss_discountinpercentage"] == null)
                            {
                                percentage = 0;
                            }
                            else
                            {
                                percentage = (decimal)entity["ss_discountinpercentage"];
                            }
                        }
                        else
                        {
                            if (preEntityImage.Attributes.Contains("ss_discountinpercentage"))
                            {
                                percentage = (decimal)preEntityImage["ss_discountinpercentage"];
                            }
                        }


                        //Building Condition for retreiving record from opportunityproduct ( WHERE opportunityid== Current ID)
                        ConditionExpression condition1 = new ConditionExpression();
                        condition1.AttributeName = "opportunityid";
                        condition1.Operator = ConditionOperator.Equal;
                        condition1.Values.Add(Opportunityid);

                        FilterExpression filter1 = new FilterExpression();
                        filter1.Conditions.Add(condition1);

                        //Query Expression for retreiving record from opportunityproduct with 
                        //above condition and below specified columns

                        QueryExpression query = new QueryExpression("opportunityproduct");
                        query.ColumnSet.AddColumns("priceperunit", "quantity", "manualdiscountamount");
                        query.Criteria.AddFilter(filter1);

                        //Geting all records in Entity Collection
                        EntityCollection result1 = service.RetrieveMultiple(query);

                        //Loop of calculating Sum of extendedamount from all Entities in Entity Collection
                        Money sumOfAmount = new Money();

                        foreach (Entity c in result1.Entities)
                        {
                            Money pricePerUnit = (Money)c["priceperunit"];
                            decimal itemQuantity = (decimal)c["quantity"];
                            decimal itemPriceDecimal = pricePerUnit.Value;
                            if (itemPriceDecimal > 0)
                            {
                                tracingService.Trace("Unit Price in SUm" + pricePerUnit.Value);
                                decimal tPrice = itemPriceDecimal * itemQuantity;
                                sumOfAmount.Value = sumOfAmount.Value + tPrice;
                            }
                        }

                        //calculating Percentage
                        percentage = percentage / 100;
                        //calculating total Discount
                        totalDiscount.Value = (percentage * sumOfAmount.Value) + discountInAmount.Value;

                        //Loop of calculating discount of each Individual Product in opportunityproduct and Update 
                        // the manualdiscountamount field

                        decimal sum_ManualDiscount = 0;
                        int noOfEntities = result1.Entities.Count();

                        int count1 = 1;
                        if(noOfEntities==0)
                        {
                            count1++;
                        }
                        foreach (Entity d in result1.Entities)
                        {
                            Money unitPrice = (Money)d["priceperunit"];
                            decimal quantityItem = (decimal)d["quantity"];
                            decimal unitPriceDecimal = unitPrice.Value;

                            if (unitPriceDecimal > 0)
                            {
                                Money itemDiscount = new Money();
                                if (sumOfAmount.Value == 0)
                                {
                                    itemDiscount.Value = 0;
                                }
                                else
                                {
                                    itemDiscount.Value = ((unitPrice.Value * quantityItem) / sumOfAmount.Value) * totalDiscount.Value;
                                }
                                itemDiscount.Value = Math.Round(itemDiscount.Value, 2);
                                sum_ManualDiscount = sum_ManualDiscount + itemDiscount.Value;
           
                                if (count1 == noOfEntities)
                                {
                                    if (sum_ManualDiscount != totalDiscount.Value)
                                    {
                                        decimal difference = totalDiscount.Value - sum_ManualDiscount;
                                        itemDiscount.Value = itemDiscount.Value + difference;
                                    }
                                }
                                d["manualdiscountamount"] = itemDiscount;
                                service.Update(d);
                                count1++;
                            }

                        }
                        if(count1>1)
                        {
                            bool a = true;
                            entity["ss_processcompleted"] = a;
                        }

                    }
                }


                catch (Exception ex)
                {
                    throw new InvalidPluginExecutionException("An error occurred in the Scalable.Xrm.Plugins.OP.UpdatePrice plug-in.", ex);
                }

            }

        }

    }
}