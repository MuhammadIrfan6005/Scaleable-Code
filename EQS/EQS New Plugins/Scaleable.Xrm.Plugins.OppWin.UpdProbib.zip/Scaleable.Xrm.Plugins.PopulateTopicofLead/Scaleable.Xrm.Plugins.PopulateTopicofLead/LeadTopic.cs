﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Scaleable.Xrm.Plugins.PopulateTopicofLead
{
    public class LeadTopic : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                #region Standard Initializations
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));


                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                ITracingService tracingService =
                    (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                #endregion Standard Initializations

                tracingService.Trace("Plugin triggered");
                tracingService.Trace("Message "+context.MessageName);

                EntityReference accountid = new EntityReference();
                int leadStatus;
                string topic = null;
                string accountName = null;
                DateTime dateNow = DateTime.Today;
                string currentYear = dateNow.ToString("yyyy");

                if (context.MessageName != "QualifyLead")
                    return;

                EntityReference leadid = (EntityReference)context.InputParameters["LeadId"];
                Entity lead = service.Retrieve("lead", leadid.Id, new ColumnSet(true));

                if (lead.Attributes.Contains("subject"))
                    topic = (string)lead["subject"];


                if (lead.Contains("parentaccountid"))
                    accountid = (EntityReference)lead["parentaccountid"];

                if (!string.IsNullOrWhiteSpace(accountid.ToString()))
                {
                    accountName = accountid.Name;
                }

                foreach (EntityReference created in (IEnumerable<object>)context.OutputParameters["CreatedEntities"])
                {
                    //Check if Account record is created when lead qualified.
                    //if (created.LogicalName == "account")
                    //{
                    //    Entity account = service.Retrieve("account", created.Id, new ColumnSet(true));
                    //}

                    //Check if Contact record is created when lead qualified.
                    //if (created.LogicalName == "contact")
                    //{
                    //    Entity contact = service.Retrieve("contact", created.Id, new ColumnSet(true));
                    //}

                    //Check if Opportunity record is created when lead qualified.
                    if (created.LogicalName == "opportunity")
                    {
                        Entity opportunity = service.Retrieve("opportunity", created.Id, new ColumnSet(true));
                        
                       
                        opportunity["name"] = accountName + " " + currentYear + " - "+topic;
                        service.Update(opportunity);
                    }
                } 
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException("Error => " +ex.Message);
            }
            
        }


    }
}
