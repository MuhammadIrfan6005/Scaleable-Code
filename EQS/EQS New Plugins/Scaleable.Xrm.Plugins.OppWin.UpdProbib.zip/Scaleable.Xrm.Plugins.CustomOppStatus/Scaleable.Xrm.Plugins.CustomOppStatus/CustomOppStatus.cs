﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Scaleable.Xrm.Plugins.CustomOppStatus
{
   
    public class CustomOppStatus : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                #region Standard Initialization
                
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                #endregion

                if (context.InputParameters.Contains("OpportunityClose") && context.InputParameters["OpportunityClose"] is Entity)
                {
                   
                    Entity entity = (Entity)context.InputParameters["OpportunityClose"];
                    Guid OppId;
                    //OptionSetValue statecode;
                    //int statecodeVal;

                    if (context.MessageName != "Win")
                        return;
                    if (entity.Attributes.Contains("opportunityid"))
                    {
                        OppId = ((EntityReference)entity.Attributes["opportunityid"]).Id;
                        tracingService.Trace("Opp iD =>" + OppId.ToString());

                        QueryExpression OppProductsQExp = GetProductQueryEpression(OppId);
                        EntityCollection OppProducts = service.RetrieveMultiple(OppProductsQExp);
                        Entity targetEntity = new Entity("opportunity", OppId);
                        if (OppProducts?.Entities?.Count > 0)
                        {
                            targetEntity.Attributes["ss_eligibleforcontract"] = true;
                        }
                        else
                        {
                            targetEntity.Attributes["ss_eligibleforcontract"] = false;
                        }

                        service.Update(targetEntity);
                    }



                }
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

        public QueryExpression GetProductQueryEpression( Guid oppId)
        {
            // Define Condition Values
            var QEopportunityproduct_opportunityid = oppId;
            var QEopportunityproduct_product_productnumber = "640050";
            var QEopportunityproduct_product_productnumber2 = "640060";
            var QEopportunityproduct_product_name = "EQS Integrity Line Best in Class";
            var QEopportunityproduct_product_name2 = "EQS Integrity Line Best Practice";
            var QEopportunityproduct_product_name3 = "EQS Integrity Line Best Practice License";
            var QEopportunityproduct_product_name4 = "EQS Integrity Line Best in Class License";

            // Instantiate QueryExpression QEopportunityproduct
            var QEopportunityproduct = new QueryExpression("opportunityproduct");

            // Add columns to QEopportunityproduct.ColumnSet
            QEopportunityproduct.ColumnSet.AddColumns("opportunityproductname");

            // Define filter QEopportunityproduct.Criteria
            QEopportunityproduct.Criteria.AddCondition("opportunityid", ConditionOperator.Equal, QEopportunityproduct_opportunityid);

            // Add link-entity QEopportunityproduct_product
            var QEopportunityproduct_product = QEopportunityproduct.AddLink("product", "productid", "productid");
            QEopportunityproduct_product.EntityAlias = "pr";

            // Add columns to QEopportunityproduct_product.Columns
            QEopportunityproduct_product.Columns.AddColumns("name");

            // Define filter QEopportunityproduct_product.LinkCriteria
            QEopportunityproduct_product.LinkCriteria.FilterOperator = LogicalOperator.Or;
            QEopportunityproduct_product.LinkCriteria.AddCondition("productnumber", ConditionOperator.Equal, QEopportunityproduct_product_productnumber);
            QEopportunityproduct_product.LinkCriteria.AddCondition("productnumber", ConditionOperator.Equal, QEopportunityproduct_product_productnumber2);
            QEopportunityproduct_product.LinkCriteria.AddCondition("name", ConditionOperator.Equal, QEopportunityproduct_product_name);
            QEopportunityproduct_product.LinkCriteria.AddCondition("name", ConditionOperator.Equal, QEopportunityproduct_product_name2);
            QEopportunityproduct_product.LinkCriteria.AddCondition("name", ConditionOperator.Equal, QEopportunityproduct_product_name3);
            QEopportunityproduct_product.LinkCriteria.AddCondition("name", ConditionOperator.Equal, QEopportunityproduct_product_name4);

            return QEopportunityproduct;
        }
       
    }
 
}
